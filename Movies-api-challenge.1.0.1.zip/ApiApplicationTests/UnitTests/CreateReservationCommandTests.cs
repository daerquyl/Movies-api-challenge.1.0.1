﻿
namespace ApiApplicationTests.UnitTests
{
    public class CreateReservationCommandTests
    {
        //TODO: Shoud write this first
    }
}

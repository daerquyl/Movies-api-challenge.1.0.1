﻿
using ApiApplication.Services;

namespace ApiApplicationTests.UnitTests
{
    public class RedisCacheServiceTests
    {
        //Should implements some tests
    }
}

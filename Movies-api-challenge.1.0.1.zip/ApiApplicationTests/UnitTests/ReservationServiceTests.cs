namespace ApiApplicationTests.UnitTests
{
    public partial class ReservationServiceTests
    {

    }
}
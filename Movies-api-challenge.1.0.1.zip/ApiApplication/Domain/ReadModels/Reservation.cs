﻿namespace ApiApplication.Domain.ReadModels
{
    public class Reservation
    {
        public string Id { get; set; }
        public int NumberfSeats { get; set; }
    }
}
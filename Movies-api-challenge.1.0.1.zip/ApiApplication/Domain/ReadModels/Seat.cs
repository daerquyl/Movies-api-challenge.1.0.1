﻿namespace ApiApplication.Domain.ReadModels
{
    public class Seat
    {
        public string Description { get; set; }
    }
}